import os
import numpy as np
import matplotlib.pyplot as plt
from netCDF4 import Dataset

# X-ray diffraction data (Soper)
data = np.loadtxt('soper13_Dn.dat')
qexp = data[:,0] / 0.1
sq_h2o = data[:,1]
sq_h2o_error = data[:,2]

plt.plot(qexp, sq_h2o, 'o', color = 'r', label = 'ND, H2O')
ax = plt.gca()
ax.errorbar(qexp, sq_h2o, yerr=sq_h2o_error, color='r')

# S(Q) computed by MDANSE
f = Dataset('SQ_waterL.nc', mode='r')
x_values = f.variables['q'][:]
x_name   = f.variables['q'].name
x_units  = f.variables['q'].units
y_values = f.variables['ssf_total'][:]
y_name   = f.variables['ssf_total'].name
y_units  = f.variables['ssf_total'].units
f.close()

plt.plot(x_values, 0.196*(y_values-0.016), color = 'k', linewidth=2.0, label = 'MD ')
plt.xlabel(x_name + ' / ' + x_units)
plt.ylabel(y_name + ' / ' + y_units)
plt.xlim((0,100))
plt.legend()
plt.show()
