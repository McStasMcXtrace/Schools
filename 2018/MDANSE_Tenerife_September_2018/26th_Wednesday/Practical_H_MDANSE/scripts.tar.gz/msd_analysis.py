import numpy as np
import matplotlib.pyplot as plt
from netCDF4 import Dataset

# Read msd output from MDANSE
data = Dataset('MSD_waterL.nc', mode='r')
time = data.variables['time'][:]
msd = data.variables['msd_total'][:]
time_units = data.variables['time'].units
msd_units = data.variables['msd_total'].units
data.close()

# Fit msd to A + 6*D*t in selected time range
time_range =  np.where( (time>20.0) & (time<60.0) )
result = np.polyfit(time[time_range], msd[time_range], 1)
D = result[0]/6.

print
print 'MSD fitted to A + 6*D*t with A = ', result[1], msd_units, ' and D = ', D, msd_units, '/', time_units

fit = result[0]*time + result[1]

plt.xlabel('time/'+time_units)
plt.ylabel('<u^2(t)>/'+msd_units)
plt.plot(time, msd, marker='o', color='r', linestyle='None', label='MD')
plt.plot(time, fit, color='k', label='Fit, D = ' + str(D))
plt.legend()
plt.show()
