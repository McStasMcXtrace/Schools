import os
import numpy as np
import matplotlib.pyplot as plt
from netCDF4 import Dataset

# X-ray diffraction data (Soper)
data = np.loadtxt('soper13_Dn.dat')
qexp = data[:,0] / 0.1
sq_d2o = data[:,7]
sq_d2o_error = data[:,8]

plt.plot(qexp, sq_d2o, 'o', color = 'r', label = 'ND, D2O')
ax = plt.gca()
ax.errorbar(qexp, sq_d2o, yerr=sq_d2o_error, color='r')

# S(Q) computed by MDANSE
f = Dataset('SQ_D2O_waterL.nc', mode='r')
x_values = f.variables['q'][:]
x_name   = f.variables['q'].name
x_units  = f.variables['q'].units
y_values = f.variables['ssf_total'][:]
y_name   = f.variables['ssf_total'].name
y_units  = f.variables['ssf_total'].units
f.close()

plt.plot(x_values, 0.4072*(y_values-1), color = 'k', linewidth=2.0, label = 'MD ')
plt.xlabel(x_name + ' / ' + x_units)
plt.ylabel(y_name + ' / ' + y_units)
plt.xlim((0,100))
plt.legend()
plt.show()
