#!/usr/bin/python

########################################################
# This is an automatically generated MDANSE run script #
########################################################

from MDANSE import REGISTRY

################################################################
# Job parameters                                               #
################################################################

parameters = {}
parameters['config_file'] = u'waterTIP4P2005_360mol.data'
parameters['mass_tolerance'] = 1e-05
parameters['n_steps'] = 2000
parameters['output_files'] = (u'waterL_traject', (u'netcdf',))
parameters['time_step'] = 1.0
parameters['trajectory_file'] = u'water.trj'

################################################################
# Setup and run the analysis                                   #
################################################################

lammps = REGISTRY['job']['lammps']()
lammps.run(parameters,status=True)
