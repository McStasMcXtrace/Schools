% currently stub -- no additional infomation is used from nxspe as par is
% not availible
%%   Overloaded methods:
%      sqw/gen_sqw_from_nxspe
%      sqw/gen_sqw_from_nxspe
%