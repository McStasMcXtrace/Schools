% Convert 2D sqw object into IXTdataset_2d
%
%   >> wout = IXTdataset_2d (w)
%%   Overloaded methods:
%      sqw/IXTdataset_2d
%      sqw/IXTdataset_2d
%      d2d/IXTdataset_2d
%