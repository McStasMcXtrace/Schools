% Display useful information from a d2d object
%
% Syntax:
%
%   >> display_single(w)
%