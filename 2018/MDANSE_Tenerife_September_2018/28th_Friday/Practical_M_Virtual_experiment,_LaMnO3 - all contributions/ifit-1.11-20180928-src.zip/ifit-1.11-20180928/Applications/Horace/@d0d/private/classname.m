% Return class name. Has to live in the private directory of the class definition directory
% because it has no argument
%