% Convert 1D sqw object into IXTdataset_1d
%
%   >> wout = IXTdataset_1d (w)
%%   Overloaded methods:
%      sqw/IXTdataset_1d
%      sqw/IXTdataset_1d
%      d1d/IXTdataset_1d
%