% Implement unary arithmetic operations for objects containing a signal and variance arrays.
%