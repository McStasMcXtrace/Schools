% Convert 3D sqw object into IXTdataset_3d
%
%   >> wout = IXTdataset_3d (w)
%%   Overloaded methods:
%      sqw/IXTdataset_3d
%      sqw/IXTdataset_3d
%      d3d/IXTdataset_3d
%