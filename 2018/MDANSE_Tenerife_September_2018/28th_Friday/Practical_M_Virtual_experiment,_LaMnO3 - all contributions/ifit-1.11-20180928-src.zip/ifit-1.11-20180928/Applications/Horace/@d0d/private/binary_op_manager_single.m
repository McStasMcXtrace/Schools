% Implement binary operator for objects with a signal and a variance array.
%