% Implement acosh(w1) for objects
%
%   >> w = acosh(w1)
%
%%   Overloaded methods:
%      sqw/acosh
%      testsigvar/acosh
%      sigvar/acosh
%      IX_dataset_3d/acosh
%      IX_dataset_2d/acosh
%      IX_dataset_1d/acosh
%      sqw/acosh
%      sigvar/acosh
%      d4d/acosh
%      d3d/acosh
%      d2d/acosh
%      d1d/acosh
%      d0d/acosh
%      codistributed/acosh
%      gpuArray/acosh
%%   Reference page in Help browser
%      doc acosh
%