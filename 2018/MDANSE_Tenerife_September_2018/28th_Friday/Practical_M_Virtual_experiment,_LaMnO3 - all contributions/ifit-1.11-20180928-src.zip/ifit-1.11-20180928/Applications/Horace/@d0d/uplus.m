function w = uplus (w1)
% Implement +w1 for objects
%
%   >> w = +w1
%

% Simply returns without change:
w = w1;
