% Create mslice/Tobyfit cut object
% 
%   >> w=cut(file)          % read from file
%   >> w=cut(structure)     % create from structure
%