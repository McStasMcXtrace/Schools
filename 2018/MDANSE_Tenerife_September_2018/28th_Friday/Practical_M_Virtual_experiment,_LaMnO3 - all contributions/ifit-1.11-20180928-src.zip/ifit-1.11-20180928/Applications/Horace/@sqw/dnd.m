% Convert input sqw object into corresponding d0d, d1d,...d4d object
%
%   >> wout = dnd (win)
%%   Overloaded methods:
%      sqw/dnd
%      sqw/dnd
%